package com.example.ponny

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
